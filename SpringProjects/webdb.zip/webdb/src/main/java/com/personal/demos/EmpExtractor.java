package com.personal.demos;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.personal.demos.Employee;
public class EmpExtractor implements ResultSetExtractor{
	 public Employee extractData(ResultSet resultSet) throws SQLException,
	   DataAccessException {
	  
	  Employee emp = new Employee();
	  
	  emp.setTECHID(resultSet.getInt(1));
	  emp.setFirstName(resultSet.getString(2));
	  emp.setLastName(resultSet.getString(3));
	  
	  return emp;
	 }
	
	
}