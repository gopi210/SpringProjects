package com.personal.demos;
import com.personal.demos.Employee;
import java.util.List;
public interface EmpInfo {
	public void AddEmp(Employee emp1);
	public void DelEmp(int EmpId);
    public void UpdEmp(Employee Emp2,int Empid);
    public Employee ViewEmp(int EmpId);
    public List<Employee> getEmployees();
}