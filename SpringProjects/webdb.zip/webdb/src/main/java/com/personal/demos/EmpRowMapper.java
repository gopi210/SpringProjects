package com.personal.demos;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.personal.demos.Employee;
public class EmpRowMapper implements RowMapper{
	@Override	
	 public Employee mapRow(ResultSet resultSet, int line) throws SQLException {
	  EmpExtractor EmpExtractor = new EmpExtractor();
	  return EmpExtractor.extractData(resultSet);
	 }
}