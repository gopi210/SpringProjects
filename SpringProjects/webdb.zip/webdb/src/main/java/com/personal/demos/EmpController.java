package com.personal.demos;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.personal.demos.EmpInfo;
@Controller
public class EmpController{
	 @Autowired
	 EmpInfo EmpIn;
     @RequestMapping("/delete")
	 public String deleteUser(@RequestParam int id) {
		  System.out.println("id = " + id);
		  EmpIn.DelEmp(id);
	  return "deleted";
	 }
}
