package com.personal.demos;
import java.util.List;
public class Employee {
	String FirstName;
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public int getTECHID() {
		return TECHID;
	}
	public void setTECHID(int tECHID) {
		TECHID = tECHID;
	}
	String LastName;
	int TECHID;
	
}