package com.personal.demos;
import com.personal.demos.Employee;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
public class EmpInfoImpl implements EmpInfo{
	@Autowired
	DataSource datasource;
	public void AddEmp(Employee emp){
		 String sql="insert into TECH"+"(IBS_TECH_ID,FIR_NM,LAST_NM) values(IBS_TECH_SEQ.NEXTVAL,?,?)";
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(datasource);
		 jdbcTemplate.update(sql);
	 }
	 public void DelEmp(int EmpID){
		 String sql="delete from TECH"+" where IBS_TECH_ID="+EmpID;
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(datasource);
		 jdbcTemplate.update(sql);
	 }
	 public void UpdEmp(Employee emp1,int EmpID){
		 String sql="update TECH set FIR_NM=?,LAST_NM=?"+" where IBS_TECH_ID="+EmpID;
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(datasource);
		 jdbcTemplate.update(sql,
				 new Object[]{emp1.getFirstName(),emp1.getLastName()});
	 }
	 public Employee ViewEmp(int EmpID){
		 List<Employee> Emp = new ArrayList();
		 String sql="select IBS_TECH_ID,FIR_NM,LAST_NM from TECH"+"where IBS_TECH_ID=?";
		 JdbcTemplate jdbcTemplate = new JdbcTemplate(datasource);
		 jdbcTemplate.query(sql,new EmpRowMapper());
		 return Emp.get(0);
	 }
	 public List<Employee> getEmployees() {
		  List EmpList = new ArrayList();

		  String sql = "select IBS_TECH_ID,FIR_NM,LAST_NM from TECH";

		  JdbcTemplate jdbcTemplate = new JdbcTemplate(datasource);
		  EmpList = jdbcTemplate.query(sql, new EmpRowMapper());
		  return EmpList;
		 }
	 
}