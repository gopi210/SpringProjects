package pcfapp_javamain;


import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ColumnDefinitions;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.UDTValue;
import com.datastax.driver.core.UserType;
import com.google.common.collect.Sets;

public class CassandraClientTest {

	private static final int MYTHREADS = 8;
	
	;
	static int count = 0;
	static String HOST = "10.97.242.197"; //the Cassandra Server host
	static int cnt = 1;
	
	
	public static void main(String args[]) throws Exception {
		Parallel p = new Parallel();
		ScheduledExecutorService executor = Executors.newScheduledThreadPool(8);
		executor.scheduleWithFixedDelay(p, 0, 1, TimeUnit.SECONDS);

	}	
	
	public static class Parallel implements Runnable {

		@Override
		public void run() {
			MyRunnable myRunnable = new MyRunnable();
			Thread t1 =new Thread(myRunnable);
			t1.start();
		}
	}
	
	public static class MyRunnable implements Runnable {
		
		@Override
		public void run() {
			System.out.println("Starting insert-" + cnt);
			cnt++;
			Cluster myCluster = Cluster.builder().addContactPoint(HOST).build();
			Session mySession = myCluster.connect("people"); //The keyspace used
			try {
				ArrayList<String> idlist = insertCassandra(myCluster, mySession, 350);
				selectCassandra(myCluster, mySession, idlist);

			} finally {
				myCluster.close();
				mySession.close();

			}
		}
		
		public ArrayList<String> insertCassandra(Cluster myCluster, Session mySession, int insertCount) {
				ArrayList<String> idlist = new ArrayList<String>();
				for (int i = 0; i < insertCount; i++) {
					String query = "insert into execution_steps(order_id,step_id,status,substatus,step_content,dependency_list,step_type,created_by,created_date,updated_by,updated_date,error_code,error_desc,first_exec_endtime,first_exec_starttime,first_res,last_exec_endtime,last_exec_starttime,last_res,request,retry_exhausted,retry_flag,current_retry_count,retry_limit,is_req_os) \n"
							+ "values(?,?,?,?,textasblob(?),?,?,?,?,?,?,?,?,?,?,textasblob(?),?,?,textasblob(?),textasblob(?),?,?,?,?,?) using  timestamp ? and TTL ?";
					PreparedStatement pstatement = mySession.prepare(query);
					BoundStatement statement = new BoundStatement(pstatement);
					String id = UUID.randomUUID().toString();
							//Integer.toString(r.nextInt());
									
					idlist.add(id);
					statement.setString(0, id);
					Random r = new Random();
					statement.setString(1, Integer.toString(r.nextInt()));
					statement.setString(2, "NEW");
					statement.setString(3, "NA");
					statement.setString(4, "NA"); // blob
					UserType userType = myCluster.getMetadata().getKeyspace("people").getUserType("exec_dependency_type");

					UDTValue udtValue = userType.newValue();
					udtValue.setString("step_id", "1");
					udtValue.setString("status", "NEW");
					statement.setSet(5, Sets.newHashSet(udtValue));
					statement.setString(6, "TEST");
					statement.setString(7, "PDS");
					statement.setTimestamp(8, new Date());
					statement.setString(9, "PDS");
					statement.setTimestamp(10, new Date());
					statement.setString(11, "NA");
					statement.setString(12, "NA");
					statement.setLong(13, new Date().getTime()); // bigint
					statement.setLong(14, new Date().getTime()); // bigint
					String strFirestrec = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>&crlf;<tns2:postNetworkProvisioningElement xmlns:tns2=\"http://tns.tibco.com/bw/json/EDANetworkProvisioning\" xmlns:tns4=\"/ordermanagement/v1/provisioning-orders/T1545313008983Converted/JsonSchema\">&crlf;  <tns2:resourcePath>/v1/eda/provisioning/line-of-services/</tns2:resourcePath>&crlf;  <tns2:NetworkProvisioningElement>&crlf;    <tns2:requestInfo>&crlf;      <tns2:messageId>METRO-QLAB02-ACT-ff2d29ff-60af-482b-bee3-cd69d7c72e9b_1</tns2:messageId>&crlf;      <tns2:source>METRO</tns2:source>&crlf;      <tns2:mode>Async</tns2:mode>&crlf;      <tns2:receiveInterimNotify>Yes</tns2:receiveInterimNotify>&crlf;    </tns2:requestInfo>&crlf;    <tns2:customerInfo>&crlf;      <tns2:customerNumber>CMPCS6715483096271</tns2:customerNumber>&crlf;      <tns2:firstName>EDA END TO END</tns2:firstName>&crlf;      <tns2:lastName>DO NOT TOUCH</tns2:lastName>&crlf;      <tns2:webSitelanguage>es</tns2:webSitelanguage>&crlf;      <tns2:accountInfo>&crlf;        <tns2:ban>BMPCS6715483096271</tns2:ban>&crlf;      </tns2:accountInfo>&crlf;      <tns2:addressInfo />&crlf;    </tns2:customerInfo>&crlf;    <tns2:lineInfo>&crlf;      <tns2:msisdn>16015646822</tns2:msisdn>&crlf;      <tns2:imsi>310260633214408</tns2:imsi>&crlf;      <tns2:imei>310260690004546</tns2:imei>&crlf;      <tns2:simSerial>8901260475962234365</tns2:simSerial>&crlf;      <tns2:brand>METRO</tns2:brand>&crlf;      <tns2:billingType>PREPAID</tns2:billingType>&crlf;      <tns2:lineType>SL</tns2:lineType>&crlf;      <tns2:language>es</tns2:language>&crlf;      <tns2:billCycleCloseDay>13</tns2:billCycleCloseDay>&crlf;      <tns2:contractCode>6715483096271</tns2:contractCode>&crlf;    </tns2:lineInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>STD</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>CLIP</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>3WC</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>SMS</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>EHR</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>SL24</tns2:feature>&crlf;      <tns2:onNetetvol>UNLIMITED</tns2:onNetetvol>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>VMG</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>CW</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>VVM</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>MUSICU</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>MMS</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;  </tns2:NetworkProvisioningElement>&crlf;  <tns2:keys>&crlf;    <tns2:keyName>X-contractcode</tns2:keyName>&crlf;    <tns2:keyValue>6715483096271</tns2:keyValue>&crlf;  </tns2:keys>&crlf;</tns2:postNetworkProvisioningElement>";		
					statement.setString(15, strFirestrec); // blob
					statement.setLong(16, new Date().getTime()); // bigint
					statement.setLong(17, new Date().getTime()); // bigint
					String lastrec ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>&crlf;<tns4:NotifyREEF xmlns:tns4=\"http://www.example.com/namespaces/tns/1532544936604\" xmlns:tns1=\"/provisioning-notification/messages/T1531497918158Converted/JsonSchema\" xmlns:tns=\"http://xmlns.example.com/20180713120941PLT/ConceptSchema\">&crlf;  <tns:provisioning-notification-messagesPutParameters>&crlf;    <tns:order-id>METRO-QLAB02-ACT-ff2d29ff-60af-482b-bee3-cd69d7c72e9b_1</tns:order-id>&crlf;  </tns:provisioning-notification-messagesPutParameters>&crlf;  <tns1:EDANotification xmlns=\"/provisioning-notification/messages/T1531497918158Converted/JsonSchema\">&crlf;    <tns1:provisioningStatusCode>0</tns1:provisioningStatusCode>&crlf;    <tns1:source>METRO</tns1:source>&crlf;    <tns1:notificationType>CORE</tns1:notificationType>&crlf;    <tns1:provisioningStatusMsg>Core provisioning is successful</tns1:provisioningStatusMsg>&crlf;  </tns1:EDANotification>&crlf;</tns4:NotifyREEF>";
					statement.setString(18, lastrec); // blob
					String req = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>&crlf;<tns2:postNetworkProvisioningElement xmlns:tns2=\"http://tns.tibco.com/bw/json/EDANetworkProvisioning\" xmlns:tns4=\"/ordermanagement/v1/provisioning-orders/T1545313008983Converted/JsonSchema\">&crlf;  <tns2:resourcePath>/v1/eda/provisioning/line-of-services/</tns2:resourcePath>&crlf;  <tns2:NetworkProvisioningElement>&crlf;    <tns2:requestInfo>&crlf;      <tns2:messageId>METRO-QLAB02-ACT-ff2d29ff-60af-482b-bee3-cd69d7c72e9b_1</tns2:messageId>&crlf;      <tns2:source>METRO</tns2:source>&crlf;      <tns2:mode>Async</tns2:mode>&crlf;      <tns2:receiveInterimNotify>Yes</tns2:receiveInterimNotify>&crlf;    </tns2:requestInfo>&crlf;    <tns2:customerInfo>&crlf;      <tns2:customerNumber>CMPCS6715483096271</tns2:customerNumber>&crlf;      <tns2:firstName>EDA END TO END</tns2:firstName>&crlf;      <tns2:lastName>DO NOT TOUCH</tns2:lastName>&crlf;      <tns2:webSitelanguage>es</tns2:webSitelanguage>&crlf;      <tns2:accountInfo>&crlf;        <tns2:ban>BMPCS6715483096271</tns2:ban>&crlf;      </tns2:accountInfo>&crlf;      <tns2:addressInfo />&crlf;    </tns2:customerInfo>&crlf;    <tns2:lineInfo>&crlf;      <tns2:msisdn>16015646822</tns2:msisdn>&crlf;      <tns2:imsi>310260633214408</tns2:imsi>&crlf;      <tns2:imei>310260690004546</tns2:imei>&crlf;      <tns2:simSerial>8901260475962234365</tns2:simSerial>&crlf;      <tns2:brand>METRO</tns2:brand>&crlf;      <tns2:billingType>PREPAID</tns2:billingType>&crlf;      <tns2:lineType>SL</tns2:lineType>&crlf;      <tns2:language>es</tns2:language>&crlf;      <tns2:billCycleCloseDay>13</tns2:billCycleCloseDay>&crlf;      <tns2:contractCode>6715483096271</tns2:contractCode>&crlf;    </tns2:lineInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>STD</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>CLIP</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>3WC</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>SMS</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>EHR</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>SL24</tns2:feature>&crlf;      <tns2:onNetetvol>UNLIMITED</tns2:onNetetvol>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>VMG</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>CW</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>VVM</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>MUSICU</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;    <tns2:featureInfo>&crlf;      <tns2:feature>MMS</tns2:feature>&crlf;    </tns2:featureInfo>&crlf;  </tns2:NetworkProvisioningElement>&crlf;  <tns2:keys>&crlf;    <tns2:keyName>X-contractcode</tns2:keyName>&crlf;    <tns2:keyValue>6715483096271</tns2:keyValue>&crlf;  </tns2:keys>&crlf;</tns2:postNetworkProvisioningElement>";
					statement.setString(19, req); // blob
					statement.setBool(20, false);
					statement.setBool(21, false);
					statement.setInt(22, 45);
					statement.setInt(23, 100);
					statement.setBool(24, false);
					statement.setLong(25,2592000);
					mySession.execute(statement);
					
				}
				
				System.out.println("Completed "+insertCount+" inserts");

			return idlist;
		}
		
		public void selectCassandra(Cluster myCluster, Session mySession, ArrayList<String> idlist) {		
			
			PreparedStatement ps = null;
			BoundStatement statement = null;
			try {

				for (String id : idlist) {
					String query = "select order_id,step_id,status,writetime(updated_date) as lastupdatetime,dependency_list as dependencylist,step_type,is_req_os from execution_steps where order_id=?";
					ps = mySession.prepare(query);
					statement = new BoundStatement(ps);
					statement.setString(0, id);
					ResultSet results = mySession.execute(statement);
					//createResponse(results);	//uncomment this to generate xml output for each query				
				}

			} catch (Exception e) {
					e.printStackTrace();	
					System.exit(0);
			} 	
		}
		
		//uncomment this to generate xml output for each query	
//		public void createResponse(ResultSet results) {			
//			
//			try {
//				DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
//				DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
//				Document document = documentBuilder.newDocument();
//				
//
//				// root element
//				Element root = document.createElement("Rows");
//				document.appendChild(root);
//
//				List<Row> rows = results.all();
//				String str = results.getColumnDefinitions().toString();
//
//				for (Row row : rows) {
//					Element xmlrow = document.createElement("Row");
//					root.appendChild(xmlrow);
//
//					for (ColumnDefinitions.Definition col : row.getColumnDefinitions()) {
//					//	System.out.println("column name :" + col.getName() + "- column Value :" + getColumnValue(col, row));
//						Element colElem = document.createElement(col.getName());
//						colElem.appendChild(document.createTextNode(getColumnValue(col, row).toString()));
//						xmlrow.appendChild(colElem);
//
//					}
//				}
//
//				TransformerFactory transformerFactory = TransformerFactory.newInstance();
//				Transformer transformer = transformerFactory.newTransformer();
//				DOMSource domSource = new DOMSource(document);
//			//	StreamResult streamResult = new StreamResult(new File("C:\\Users\\pkelveka\\Desktop\\xmlfile.xml"));
//			//	transformer.transform(domSource, streamResult);
//				
//				StringWriter writer = new StringWriter();
//				transformer.transform(domSource, new StreamResult(writer));
//				String xmlString = writer.getBuffer().toString();  
//				 
//				System.out.println(xmlString);
//			
//				
//			} catch (TransformerConfigurationException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (ParserConfigurationException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (TransformerException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//	
//		}
//		
//		public Object getColumnValue(ColumnDefinitions.Definition col, Row row) {
//
//			String colName = col.getName();
//			Object value = null;
//
//			switch (col.getType().getName().name()) {
//			case "ASCII":
//				value = row.getString(colName);
//				break;
//			case "INET":
//				if (row.getInet(colName) != null) {
//					value = row.getInet(colName).toString();
//				}
//				break;
//			case "TEXT":
//				value = row.getString(colName);
//				break;
//			case "UUID":
//				if (row.getUUID(colName) != null) {
//					value = row.getUUID(colName).toString();
//				}
//				break;
//			case "TIMEUUID":
//				if (row.getUUID(colName) != null) {
//					value = row.getUUID(colName).toString();
//				}
//				break;
//			case "VARCHAR":
//				value = row.getString(colName);
//				break;
//			case "BIGINT":
//				value = row.getLong(colName);
//				break;
//			case "COUNTER":
//				value = row.getLong(colName);
//				break;
//			case "DECIMAL":
//				value = row.getDecimal(colName);
//				break;
//			case "INT":
//				value = row.getInt(colName);
//				break;
//			case "VARINT":
//				if (row.getVarint(colName) != null) {
//					value = row.getVarint(colName).intValue();
//				}
//				break;
//			case "BLOB":
//				// atom = atomBridge.createBase64Binary(row.getBytes(parameterName).array());
//				if (row.getBytes(colName) != null) {
//					// atom= atomBridge.createBase64Binary(row.getBytes(parameterName).array());
//					value = row.getBytes(colName).array();
//				}
//				break;
//			case "BOOLEAN":
//				value = row.getBool(colName);
//				break;
//			case "DOUBLE":
//				value = row.getDouble(colName);
//				break;
//			case "FLOAT":
//				row.getFloat(colName);
//				break;
//			case "TIMESTAMP":
//				value = row.getTimestamp(colName);
//
//				break;
//			case "TIME":
//				// FIX for JIRA BWAC-85
//				value = row.getTime(colName);
//				break;
//
//			case "SMALLINT":
//				value = row.getShort(colName);
//				break;
//
//			case "TINYINT":
//				value = row.getByte(colName);
//				break;
//
//			case "DATE":
//				value = row.getDate(colName);
//				break;
//
//			default:
//				value = row.getObject(colName);
//				
////				if(col.getType().getName().name().equalsIgnoreCase("list")){
////                    col.getType().getTypeArguments().get(0);
////                    
////                } else if(col.getType().getName().name().equalsIgnoreCase("set")){
////                    col.getType().getTypeArguments().get(0);
////                } else if(col.getType().getName().name().equalsIgnoreCase("map")){
////                    col.getType().getTypeArguments().get(0);
////                    col.getType().getTypeArguments().get(1);
////                } else {
////                	
////                    UserType ut = (UserType) col.getType();
////                    UDTValue udt = row.get
////                    for (String fieldname : ut.getFieldNames()){
////                        ut.getFieldType(fieldname);
////                    }
////                        
////                    
////                }
//				break;
//			}
//			return value;
//
//		}
//	
	}
}